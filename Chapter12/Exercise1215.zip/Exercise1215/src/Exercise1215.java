
import java.util.*;
import java.io.*;

public class Exercise1215 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file = new File("Exercise12_15");
		
		if (!file.exists()) {
			
			try(PrintWriter output = new PrintWriter(file)){
				for (int i = 0; i < 100; i++) {
					int randomInt = (int) (Math.random() * 1000);
					output.print(randomInt + " ");
				}
			}
			
			System.out.println("File created and 100 integers written.");
			
		} else {
			System.out.println("File already exists.");
		}
		
		int[] num = new int[100];
		try(Scanner input = new Scanner(file)){
			for (int i = 0; i < num.length; i++) {
				num[i] = input.nextInt();
			}
		}
		
		Arrays.sort(num);
		
		
		System.out.println("Sorted Integers: ");
		
		for (int nums : num) {
			System.out.print(nums + " ");
		}
	}
}
