import java.util.Random;

import java.util.Scanner;


public class Exercise123 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num = new int[100];
		
		Random random = new Random();
		
		for (int i = 0; i < num.length; i++) {
			num[i] = random.nextInt(1000);
		}
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter an index (0-99): ");
		
		try {
			int index = input.nextInt();
			
			
			System.out.println("Element at index " + index + ": " + num[index]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Out of Bounds");
		} finally {
			input.close();
		}
	}

}
